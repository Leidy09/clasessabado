<!DOCTYPE html>
<html>
    <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1">
          <link rel="stylesheet" href="css/style.css" type="text/css" />
          <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
          <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
          <title>PERIODO</title>
    </head>
    <body>
        
<nav  class="navbar navbar-default navbar-fixed-top">
  <h1>PERIODO</h1>
  <div class="container-fluid">
    <div class="navbar-header">
      <ul class="nav navbar-nav">
        <li><a href="">Docentes</a></li>
        <li><a href="">Estudiantes</a></li>
        <li><a href="">Materia</a></li>
        <li><a href="">Usuario</a></li>
        <li><a href="">Eventos</a></li>
        <li><a href="">Periodo</a></li>
      </ul>
      <button class="">Cerrar sesión</button>
    </div>
  </div>
</nav>

      <label for="">Nombre</label>
      <input type="text" name=""/>
      <button>Ingresar</button>
      <input type="text" name="buscar" placeholder="Search"/>
<div class="container">
  <table class=" table table-striped">
    <thead>
      <tr>
        <th>PERIODO</th>
        <th>ACCIONES</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>PERIODO1</td>
        <td><button class=" btn btn-success">Editar</button></td>
        <td><button class="btn btn-danger">Eliminar</button></td>
      </tr>
      <tr>
        <td>PERIODO2</td>
        <td><button class="btn btn-success">Editar</button></td>
        <td><button class="btn btn-danger">Eliminar</button></td>
      </tr>
      <tr>
        <td>PERIODO3</td>
        <td><button class="btn btn-success">Editar</button></td>
        <td><button class="btn btn-danger">Eliminar</button></td>
      </tr>
      <tr>
        <td>PERIODO4</td>
        <td><button class="btn btn-success">Editar</button></td>
        <td><button class="btn btn-danger">Eliminar</button></td>
      </tr>
    </tbody>
  </table>
</div>

</body>
        
        
    
    </body>
</html>