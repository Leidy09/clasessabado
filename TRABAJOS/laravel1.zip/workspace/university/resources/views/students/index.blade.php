<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
          
   
    <title>LIST STUDENTS</title>
</head>
<body>
     <h1>STUDENTS</h1>
     <a href="{{url('students/create')}}" class="btn btn-primary">Crear estudiante</a>
        @csrf
        <div class="container">
            <br>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Student_No°</th>
                        <th>Student_LastName</th>
                        <th>Student_FirstName</th>
                        <th>Student_City°</th>
                        <th>Student_state</th>
                        <th>Student_Zip</th>
                        <th>Student_Major</th>
                        <th>Student_Class</th>
                        <th>Student_Gpa</th>
                        <th>CREATED</th>
                        <th>UPDATE</th>
                        <th colspan="2">Acciones</th>
                    </tr>
                </thead>
        </div>
               <tbody>
                    @foreach($students as $student)
                    <tr>
                        <td>{{$student['Student_No']}}</td>     
                        <td>{{$student['Student_LastName']}}</td>     
                        <td>{{$student['Student_FirstName']}}</td>     
                        <td>{{$student['Student_City']}}</td>     
                        <td>{{$student['Student_state']}}</td>     
                        <td>{{$student['Student_Zip']}}</td>     
                        <td>{{$student['Student_Major']}}</td>     
                        <td>{{$student['Student_Class']}}</td>     
                        <td>{{$student['Student_Gpa']}}</td> 
                        <td>{{$student['created_at']}}</td>     
                        <td>{{$student['updated_at']}}</td> 
                    
                     <td aling="rigth">
                            
                            <a href="{{action('StudentController@edit', $student->Student_No)}}" class="btn btn-warning">UPDATE</a></td>
                            
                          <td><form  action="{{action('StudentController@destroy', $student-> Student_No)}}" method='post'>
                                @csrf
                                <input type="hidden" name="_method" value="DELETE"/>
                                <button class="btn btn-danger" type="submit">DELETE</button>
                            </form>
                        </td>
                    </tr>

                    @endforeach
               </tbody>
            </table>
    </body>
</html>