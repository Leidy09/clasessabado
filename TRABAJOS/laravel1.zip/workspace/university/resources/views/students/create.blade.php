<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
          
    <title>STUDENT</title>
</head>
<body>
    <form method="post" action="{{url('students')}}">  
        @csrf
        <div class="container">
            <div class="control-label col-sm-4" >
                
                <label for="studentno">Student_No°</label>
                <input type="text" name="studentno" class="form-control"/>
            
                <label for="lastname">Student_LastName</label>
                <input type="text" name="lastname" class="form-control"/>
            
                <label for="firstname">Student_Firstname</label>
                <input type="text" name="firstname" class="form-control"/>
            
                <label for="city">Student_City</label>
                <input type="text" name="city" class="form-control"/>
            
             <label for="state">Student_state</label>
                <input type="text" name="state" class="form-control"/>
            
             <label for="zip">Student_Zip</label>
                <input type="text" name="zip" class="form-control"/>
            
             <label for="major">Student_Major</label>
                <input type="text" name="major" class="form-control"/>
             
             <label for="class">Student_Class</label>
                <input type="text" name="class" class="form-control"/>
            
             <label for="gpa">Student_Gpa</label>
            <input type="text" name="gpa" class="form-control"/>
        
                <button type="Submit" class="btn btn-success">ENVIAR</button>
            </div>
        </div>
    </form>
    
</body>
</html>