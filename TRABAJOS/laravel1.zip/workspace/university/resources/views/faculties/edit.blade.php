<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
          <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
          
    <title>FACULTY</title>
    
</head>
<body>
    <h1>EDIT FACULTY</h1>
            
    <form method="post" action="{{action('FacultyController@update', $Faculty_No)}}">  
        @csrf
        <input type="hidden" name="_method" value="PUT"/>
        <div class="container">
            
            <h2>EDIT FACULTY</h2>
            
            <div class="control-label col-sm-2" >
                <label for="facultyno">Faculty_No°</label>
                <input type="text" name="facultyno" class="form-control"/>
            
                <label for="firstname">Faculty_FirstName</label>
                <input type="text" name="firstname" class="form-control"/>
            
                <label for="lastname">Faculty_LastName</label>
                <input type="text" name="lastname" class="form-control"/>
            
                <label for="city">Faculty_City</label>
                <input type="text" name="city" class="form-control"/>
            
                <label for="state">Faculty_state</label>
                <input type="text" name="state" class="form-control"/>
            
                <label for="zip">Faculty_Zip</label>
                <input type="number" name="zip" class="form-control"/>
            
                <label for="rank">Faculty_Rank</label>
                <input type="text" name="rank" class="form-control"/>
            
                <label for="hiredate">Faculty_HireDate</label>
                <input type="text" name="hiredate" class="form-control"/>
            
                <label for="salary">Faculty_Salary</label>
                <input type="number" name="salary" class="form-control"/>
            
                <label for="supervisor">Faculty_Supervisor</label>
                <input type="text" name="supervisor" class="form-control"/>
            
                <label for="departament">Faculty_Departament</label>
                <input type="text" name="departament" class="form-control"/>
                
                
                <button type="Submit" class="btn btn-success">ENVIAR</button>
            </div>
        </div>
    </form>
    
</body>
</html>