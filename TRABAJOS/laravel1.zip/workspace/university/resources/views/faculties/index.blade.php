<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
          
   
    <title>LIST FACULTY</title>
</head>
<body>
       <h2>LIST FACULTY</h2>
       <a href="{{url('faculties/create')}}" class="btn btn-primary">Crear estudiante</a>
        @csrf
        <div class="container">
            <br>
            <table class="table table-striped ">
                <thead>
                    <tr>
                        <th>Faculty_No°</th>
                        <th>Faculty_FirstName</th>
                        <th>Faculty_LastName</th>
                        <th>Faculty_City</th>
                        <th>Faculty_state</th>
                        <th>Faculty_Zip</th>
                        <th>Faculty_Rank</th>
                        <th>Faculty_HireDate</th>
                        <th>Faculty_Salary</th>
                        <th>Faculty_Supervisor</th>
                        <th>Faculty_Departament</th>
                        <th>CREATED</th>
                        <th>UPDATE</th>
                        <th colspan="2">Acciones</th>
                        
                    </tr>
                </thead>
        </div>
               <tbody>
                    @foreach($faculties as $faculty)
                    <tr>
                        <td>{{$faculty['Faculty_No']}}</td>     
                        <td>{{$faculty['Faculty_FirstName']}}</td>     
                        <td>{{$faculty['Faculty_LastName']}}</td>     
                        <td>{{$faculty['Faculty_City']}}</td>     
                        <td>{{$faculty['Faculty_state']}}</td>
                        <td>{{$faculty['Faculty_Zip']}}</td>     
                        <td>{{$faculty['Faculty_Rank']}}</td>     
                        <td>{{$faculty['Faculty_HireDate']}}</td>     
                        <td>{{$faculty['Faculty_Salary']}}</td>                     
                        <td>{{$faculty['Faculty_Supervisor']}}</td>     
                        <td>{{$faculty['Faculty_Departament']}}</td>     
                        <td>{{$faculty['created_at']}}</td>     
                        <td>{{$faculty['updated_at']}}</td> 
                        
                        <td aling="rigth">
                            
                            <a href="{{action('FacultyController@edit', $faculty->Faculty_No)}}" class="btn btn-warning">UPDATE</a>
                        
                        </td>
                            
                        <td>
                            <form  action="{{action('FacultyController@destroy', $faculty->Faculty_No)}}" method='post'>
        
                                
                                @csrf
                                <input type="hidden" name="_method" value="DELETE"/>
                                <button class="btn btn-danger" type="submit">DELETE</button>
                            </form>
                        </td>
                    </tr>
                    @endforeach
               </tbody>
            </table>
    </body>
</html>