<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="uft-8">
        <title>OFFERING</title>
    </head>
    <body>
        <h1>COURSE</h1>
        <label for="">Offering Add</label>
        
        
    </body>
</html>