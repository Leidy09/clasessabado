<!DOCTYPE html>
<html>
    <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1">
          <link rel="stylesheet" href="/css/styleLog.css" type="text/css"/>
          <link rel="stylesheet" type="text/css" href="/css/stilo.css">
          <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
          <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
          <title>PERIODO</title>
    </head>
<body>
<div class="container-fluid fondo"
  <form class="form-group">
      <div class="control-label col-sm-6">
           <div class="form-group">
             <label for="">Nombre</label>
              <input type="text" name="" class="form-control nom"/> 
           </div>
            <button type="submit" name="Enviar" class="btn btn-success active ">Registrar</button>
            
      </div>
    </form>
</div>      
<div class="control-label col-sm-4 lu">
    <div class="form-group">
    <input type="text" class="form-control" placeholder="Buscar">
</div>
    <button class="btn btn-info lup" type="submit" name="lupa" id="bt"><i class="glyphicon glyphicon-search"></i></button>   
       
  
     
<div  class="container table">
  
  <table class=" table table-striped">
    <thead>
      <tr>
        <th>PERIODO</th>
        <th>ACCIONES</th>
      </tr>
    </thead>
        <tbody>
          <tr>
            <td></td>
            <td></td> 
          </tr>
         
        </tbody>
  </table>
</div>

</body>
        
        
    
    </body>
</html>