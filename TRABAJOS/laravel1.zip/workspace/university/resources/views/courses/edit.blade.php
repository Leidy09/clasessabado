<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
          <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
          
    <title>COURSES</title>
    
</head>
<body>
    <h1>EDIT COURSES</h1>
            
    <form method="post" action="{{action('CourseController@update', $Course_No)}}">  
        @csrf
        <input type="hidden" name="_method" value="PUT"/>
        <div class="container">
            
            <h2>EDIT COURSES</h2>
            
            <div class="control-label col-sm-2" >
                <label for="courseno">COURSES_N°</label>
                <input type="text" name="courseno" class="form-control" disabled="disabled" value="{{$course->Course_No}}"/>
            
                <label for="desc">DESCRIPTION</label>
                <input type="text" name="desc" class="form-control" value="{{$course->Course_Desc}}"/>
            
                <label for="units">UNITS</label>
                <input type="number" name="units" class="form-control" value="{{$course->CRS_Units}}"/>
            
                <button type="Submit" class="btn btn-success">ENVIAR</button>
            </div>
        </div>
    </form>
    
</body>
</html>