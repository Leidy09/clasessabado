<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
          
   
    <title>LIST COURSES</title>
</head>
<body>
      
        @csrf
        <div class="container">
            <h2>COURSES</h2>
            <a href="{{url('courses/create')}}" class="btn btn-primary">Crear Estudiante</a>
            <br>
            <table class="table table-striped ">
                <thead>
                    <tr>
                        <th>COURSES_N°</th>
                        <th>DESCRIPTION</th>
                        <th>UNITS</th>
                        <th>CREATED</th>
                        <th>UPDATE</th>
                        
                    </tr>
                </thead>
        </div>
               <tbody>
                    @foreach($courses as $course)
                    <tr>
                        <td>{{$course['Course_No']}}</td>     
                        <td>{{$course['Course_Desc']}}</td>     
                        <td>{{$course['CRS_Units']}}</td>     
                        <td>{{$course['created_at']}}</td>     
                        <td>{{$course['updated_at']}}</td> 
                        <td aling="rigth">
                            
                            <a href="{{action('CourseController@edit',$course['Course_No'])}}" class="btn btn-warning">UPDATE</a>
                            
                            <form action="{{action('CourseController@destroy',$course->Course_No)}}" method='post'>
                                @csrf
                                <input type="hidden" name="_method" value="DELETE"/>
                                <button class="btn btn-danger" type="submit">DELETE</button>
                            </form>
                        </td>
                    </tr>
                    @endforeach
               </tbody>
            </table>
    </body>
</html>