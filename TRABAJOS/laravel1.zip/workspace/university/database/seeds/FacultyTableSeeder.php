<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class FacultyTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      /*DB::table('faculties')->insert([
            'Faculty_No' =>'543-21-0987',
            'Faculty_Firstname' =>'VICTORIA',
            'Faculty_Lastname' =>'EMMANUEL',
            'Faculty_City' =>'BOTHELL',
            'Faculty_state' =>'WA',
            'Faculty_Zip' =>'98011-2242',
            'Faculty_Rank' =>'PROF',
            'Faculty_HireDate' =>'2001-04-15',
            'Faculty_Salary' =>120000.0,
            'Faculty_Supervisor' =>'',
            'Faculty_Departament' =>'MS',
            
            ]);
    
      DB::table('faculties')->insert([
            'Faculty_No' =>'765-43-2109',
            'Faculty_Firstname' =>'NICKI',
            'Faculty_Lastname' =>'MACON',
            'Faculty_City' =>'BELLEVUE',
            'Faculty_state' =>'WA',
            'Faculty_Zip' =>'98015-9945',
            'Faculty_Rank' =>'PROF',
            'Faculty_HireDate' =>'2002-04-11',
            'Faculty_Salary' =>65000.00,
            'Faculty_Supervisor' =>'',
            'Faculty_Departament' =>'FIN',
            
            ]);
    
      DB::table('faculties')->insert([
            'Faculty_No' =>'654-32-1098',
            'Faculty_Firstname' =>'LEONARD',
            'Faculty_Lastname' =>'FIBON',
            'Faculty_City' =>'SEATTLE',
            'Faculty_state' =>'WA',
            'Faculty_Zip' =>'98121-0094',
            'Faculty_Rank' =>'ASSC',
            'Faculty_HireDate' =>'1999-05-01',
            'Faculty_Salary' =>70000.00,
            'Faculty_Supervisor' =>'543-21-0987',
            'Faculty_Departament' =>'MS',
            
            ]);
    
      DB::table('faculties')->insert([
            'Faculty_No' =>'098-76-5432',
            'Faculty_Firstname' =>'LEONARD',
            'Faculty_Lastname' =>'VINCE',
            'Faculty_City' =>'SEATTLE',
            'Faculty_state' =>'WA',
            'Faculty_Zip' =>'98111-9921',
            'Faculty_Rank' =>'ASST',
            'Faculty_HireDate' =>'2000-04-10',
            'Faculty_Salary' =>35000.00,
            'Faculty_Supervisor' =>'654-32-1098',
            'Faculty_Departament' =>'MS',
            
            ]);
            
            
      DB::table('faculties')->insert([
            'Faculty_No' =>'876-54-3210',
            'Faculty_Firstname' =>'CRISTHOPER',
            'Faculty_Lastname' =>'COLAN',
            'Faculty_City' =>'SEATTLE',
            'Faculty_state' =>'WA',
            'Faculty_Zip' =>'98114-1332',
            'Faculty_Rank' =>'ASST',
            'Faculty_HireDate' =>'2004-05-01',
            'Faculty_Salary' =>40000.00,
            'Faculty_Supervisor' =>'654-32-1098',
            'Faculty_Departament' =>'MS,
            
            ]);
    
      DB::table('faculties')->insert([
            'Faculty_No' =>'987-65-4321',
            'Faculty_Firstname' =>'JULIA',
            'Faculty_Lastname' =>'MILLS',
            'Faculty_City' =>'SEATTLE',
            'Faculty_state' =>'WA',
            'Faculty_Zip' =>'98114-9954',
            'Faculty_Rank' =>'ASSC',
            'Faculty_HireDate' =>'2005-03-15',
            'Faculty_Salary' =>75000.00,
            'Faculty_Supervisor' =>'765-43-2109',
            'Faculty_Departament' =>'FIN',
            
            ]);*/
           
    }
}
