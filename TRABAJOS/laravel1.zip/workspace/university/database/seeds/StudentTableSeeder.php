<?php

use Illuminate\Database\Seeder;

class StudentTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
         /*DB::table('students')->insert([
            'Student_No' =>'123-45-6789',
            'Student_LastName' =>'HOMER',
            'Student_Firstname' =>'HOMER',
            'Student_City' =>'SEATTLE',
            'Student_state' =>'WA',
            'Student_Zip' =>'98121-1111',
            'Student_Major' =>'IS',
            'Student_Class' =>'FR',
            'Student_Gpa' =>3.00,
            ]);
            
            
            DB::table('students')->insert([
            'Student_No' =>'124-56-7890',
            'Student_LastName' =>'BOB',
            'Student_Firstname' =>'NORBERT',
            'Student_City' =>'BOTHELL',
            'Student_state' =>'WA',
            'Student_Zip' =>'98011-2121',
            'Student_Major' =>'FIN',
            'Student_Class' =>'JR',
            'Student_Gpa' =>2.70,
            ]);
            
            DB::table('students')->insert([
            'Student_No' =>'234-56-7890',
            'Student_LastName' =>'CANDY',
            'Student_Firstname' =>'KENDALL',
            'Student_City' =>'TACOMA',
            'Student_state' =>'WA',
            'Student_Zip' =>'98123-1141',
            'Student_Major' =>'IS',
            'Student_Class' =>'SR',
            'Student_Gpa' =>2.80,
            ]);
            
            DB::table('students')->insert([
            'Student_No' =>'456-78-9012',
            'Student_LastName' =>'JOE',
            'Student_Firstname' =>'ESTRADA',
            'Student_City' =>'SEATTLE',
            'Student_state' =>'WA',
            'Student_Zip' =>'98121-2333',
            'Student_Major' =>'FIN',
            'Student_Class' =>'SR',
            'Student_Gpa' =>3.20
            ]);
            
            DB::table('students')->insert([
            'Student_No' =>'567-89-0123',
            'Student_LastName' =>'MARIAH',
            'Student_Firstname' =>'DODGE',
            'Student_City' =>'SEATTLE',
            'Student_state' =>'WA',
            'Student_Zip' =>'98114-0021',
            'Student_Major' =>'IS',
            'Student_Class' =>'JR',
            'Student_Gpa' =>3.60,
            ]);
            
            DB::table('students')->insert([
            'Student_No' =>'678-90-1234',
            'Student_LastName' =>'TESS',
            'Student_Firstname' =>'DODGE',
            'Student_City' =>'REDMOND',
            'Student_state' =>'WA',
            'Student_Zip' =>'98116-2344',
            'Student_Major' =>'ACCT',
            'Student_Class' =>'SO',
            'Student_Gpa' =>3.30,
            ]);
            
            DB::table('students')->insert([
            'Student_No' =>'789-01-2345',
            'Student_LastName' =>'ROBERTO',
            'Student_Firstname' =>'MORALES',
            'Student_City' =>'SEATTLE',
            'Student_state' =>'WA',
            'Student_Zip' =>'98121-2212',
            'Student_Major' =>'FIN',
            'Student_Class' =>'JR',
            'Student_Gpa' =>2.50,
            ]);
            
            DB::table('students')->insert([
            'Student_No' =>'876-54-3210',
            'Student_LastName' =>'CRISTOPHER',
            'Student_Firstname' =>'COLAN',
            'Student_City' =>'SEATTLE',
            'Student_state' =>'WA',
            'Student_Zip' =>'98114-1332',
            'Student_Major' =>'IS',
            'Student_Class' =>'SR',
            'Student_Gpa' =>4.00,
            ]);
            
            DB::table('students')->insert([
            'Student_No' =>'890-12-3456',
            'Student_LastName' =>'LUKE',
            'Student_Firstname' =>'BRAZZI',
            'Student_City' =>'SEATTLE',
            'Student_state' =>'WA',
            'Student_Zip' =>'98116-0021',
            'Student_Major' =>'IS',
            'Student_Class' =>'SR',
            'Student_Gpa' =>2.20,
            ]);
            
            DB::table('students')->insert([
            'Student_No' =>'901-23-4567',
            'Student_LastName' =>'WILLIAM',
            'Student_Firstname' =>'PILGRIM',
            'Student_City' =>'BOTHELL',
            'Student_state' =>'WA',
            'Student_Zip' =>'98113-1885',
            'Student_Major' =>'IS',
            'Student_Class' =>'SO',
            'Student_Gpa' =>3.80,
            ]);*/
            
           
    }
}
