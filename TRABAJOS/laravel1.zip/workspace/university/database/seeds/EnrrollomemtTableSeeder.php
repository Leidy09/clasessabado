<?php

use Illuminate\Database\Seeder;
use Iluminate\Support\Facades\DB;

class EnrrollomemtTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        /*DB::table('enrrollomet')->insert([
            'Offering_No' =>'1234',
            'Student_No' =>'123-45-6789',
            'enrolloment_grade' =>3.30,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'1234',
            'Student_No' =>'234-56-7890',
            'enrolloment_grade' =>3.50,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'1234',
            'Student_No' =>'345-67-8901',
            'enrolloment_grade' =>3.20,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'1234',
            'Student_No' =>'456-78-9012',
            'enrolloment_grade' =>3.10,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'1234',
            'Student_No' =>'567-89-0123',
            'enrolloment_grade' =>3.80,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'1234',
            'Student_No' =>'678-90-1234',
            'enrolloment_grade' =>3.40,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'4321',
            'Student_No' =>'123-45-6789',
            'enrolloment_grade' =>3.50,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'4321',
            'Student_No' =>'124-56-7890',
            'enrolloment_grade' =>3.20,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'4321',
            'Student_No' =>'789-01-2345',
            'enrolloment_grade' =>3.50,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'4321',
            'Student_No' =>'876-54-3210',
            'enrolloment_grade' =>3.10,
         ]);
         DB::table('enrrollomet')->insert([
            'Offering_No' =>'4321',
            'Student_No' =>'890-12-3456',
            'enrolloment_grade' =>3.40,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'4321',
            'Student_No' =>'901-23-4567',
            'enrolloment_grade' =>3.10,
         ]);
         DB::table('enrrollomet')->insert([
            'Offering_No' =>'5555',
            'Student_No' =>'123-45-6789',
            'enrolloment_grade' =>3.20,
         ]);
         DB::table('enrrollomet')->insert([
            'Offering_No' =>'5555',
            'Student_No' =>'124-56-7890',
            'enrolloment_grade' =>2.70,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'5678',
            'Student_No' =>'123-45-6789',
            'enrolloment_grade' =>3.20,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'5678',
            'Student_No' =>'234-56-7890',
            'enrolloment_grade' =>2.80,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'5678',
            'Student_No' =>'345-67-8901',
            'enrolloment_grade' =>3.30,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'5678',
            'Student_No' =>'456-78-9012',
            'enrolloment_grade' =>3.40,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'5678',
            'Student_No' =>'567-89-0123',
            'enrolloment_grade' =>2.60,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'5678',
            'Student_No' =>'123-45-6789',
            'enrolloment_grade' =>2.00,
         ]);
          DB::table('enrrollomet')->insert([
            'Offering_No' =>'5678',
            'Student_No' =>'124-56-7890',
            'enrolloment_grade' =>3.70,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'5679',
            'Student_No' =>'678-90-1234',
            'enrolloment_grade' =>3.30,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'5679',
            'Student_No' =>'124-45-6789',
            'enrolloment_grade' =>2.00,
         ]);
       
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'5679',
            'Student_No' =>'124-56-7890',
            'enrolloment_grade' =>3.70,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'5679',
            'Student_No' =>'678-90-1234',
            'enrolloment_grade' =>3.30,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'5679',
            'Student_No' =>'789-01-2345',
            'enrolloment_grade' =>3.80,
         ]);
       
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'5679',
            'Student_No' =>'890-12-3456',
            'enrolloment_grade' =>2.9,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'5679',
            'Student_No' =>'901-23-4567',
            'enrolloment_grade' =>3.1,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'6666',
            'Student_No' =>'234-56-7890',
            'enrolloment_grade' =>3.1,
         ]);
       
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'6666',
            'Student_No' =>'567-89-0123',
            'enrolloment_grade' =>3.6,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'7777',
            'Student_No' =>'876-54-3210',
            'enrolloment_grade' =>3.4,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'7777',
            'Student_No' =>'890-12-3456',
            'enrolloment_grade' =>3.7,
         ]);
       
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'7777',
            'Student_No' =>'901-23-4567',
            'enrolloment_grade' =>3.4,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'9876',
            'Student_No' =>'124-56-7890',
            'enrolloment_grade' =>3.5,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'9876',
            'Student_No' =>'234-56-7890',
            'enrolloment_grade' =>3.2,
         ]);
       
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'9876',
            'Student_No' =>'345-67-8901',
            'enrolloment_grade' =>3.2,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'9876',
            'Student_No' =>'456-78-9012',
            'enrolloment_grade' =>3.4,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'9876',
            'Student_No' =>'567-89-0123',
            'enrolloment_grade' =>2.6,
         ]);
       
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'9876',
            'Student_No' =>'678-90-1234',
            'enrolloment_grade' =>3.1,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'9876',
            'Student_No' =>'901-23-4567',
            'enrolloment_grade' =>4,
         ]);
        DB::table('enrrollomet')->insert([
            'Offering_No' =>'',
            'Student_No' =>'',
            'enrolloment_grade' =>'',
         ]);*/
       
       
    }
}
