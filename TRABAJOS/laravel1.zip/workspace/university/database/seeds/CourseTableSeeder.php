<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use app\Course;
class CourseTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      
       factory(Course::class, 5)->create();
       
       
        /*DB::table('courses')->insert([
            'Course_No' =>'FIN300',
            'Course_Desc' =>'FUNDAMENTALS OF FINANCE',
            'CRS_Units' =>'4',
        ]);
        
          DB::table('courses')->insert([
            'Course_No' =>'FIN450',
            'Course_Desc' =>'PRINCIPLES OF INVESTMENTS',
            'CRS_Units' =>'4',
        ]);
        
          DB::table('courses')->insert([
            'Course_No' =>'FIN480',
            'Course_Desc' =>'CORPORATE FINANCE',
            'CRS_Units' =>'4',
        ]);
        
          DB::table('courses')->insert([
            'Course_No' =>'IS320',
            'Course_Desc' =>'FUNDAMENTALS OF BUSINESS PROGRAMMING',
            'CRS_Units' =>'4',
        ]);
        
          DB::table('courses')->insert([
            'Course_No' =>'IS460',
            'Course_Desc' =>'SYSTEMS ANALYSIS',
            'CRS_Units' =>'4',
        ]);*/
    }
}
