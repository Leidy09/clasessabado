<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class OfferingTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
       
         /*DB::table('offerings')->insert([
            'Offering_No' =>'1111',
            'Course_No' =>'IS320',
            'Offering_M' =>'BLM302',
            'Offering_Year' =>'2013',
            'Offering_Location' =>'SUMMER',
            'Offering_Time' =>'10:30:00',
            'Faculty_No' =>'',
            'Offering_Days' =>'MW',
            ]);
            
        DB::table('offerings')->insert([
            'Offering_No' =>'1234',
            'Course_No' =>'IS320',
            'Offering_M' =>'BLM302',
            'Offering_Year' =>'2012',
            'Offering_Location' =>'FALL',
            'Offering_Time' =>'10:30:00',
            'Faculty_No' =>'098-76-5432',
            'Offering_Days' =>'MW',
            ]);
        
        DB::table('offerings')->insert([
            'Offering_No' =>'2222',
            'Course_No' =>'IS460',
            'Offering_M' =>'BLM412',
            'Offering_Year' =>'2012',
            'Offering_Location' =>'SUMMER',
            'Offering_Time' =>'13:30:00',
            'Faculty_No' =>'',
            'Offering_Days' =>'TTH',
            ]);
        
        DB::table('offerings')->insert([
            'Offering_No' =>'3333',
            'Course_No' =>'IS320',
            'Offering_M' =>'BLM214',
            'Offering_Year' =>'2013',
            'Offering_Location' =>'SPRING',
            'Offering_Time' =>'08:30:00',
            'Faculty_No' =>'098-76-5432',
            'Offering_Days' =>'MW',
            ]);
        
        DB::table('offerings')->insert([
            'Offering_No' =>'4321',
            'Course_No' =>'IS320',
            'Offering_M' =>'BLM214',
            'Offering_Year' =>'2012',
            'Offering_Location' =>'FALL',
            'Offering_Time' =>'15:30:00',
            'Faculty_No' =>'098-76-5432',
            'Offering_Days' =>'TTH',
            ]);
        
        DB::table('offerings')->insert([
            'Offering_No' =>'4444',
            'Course_No' =>'IS320',
            'Offering_M' =>'BLM302',
            'Offering_Year' =>'2013',
            'Offering_Location' =>'WINTER',
            'Offering_Time' =>'15:30:00',
            'Faculty_No' =>'543-21-0987',
            'Offering_Days' =>'TTH',
            ]);
        
        DB::table('offerings')->insert([
            'Offering_No' =>'5555',
            'Course_No' =>'FIN300',
            'Offering_M' =>'BLM207',
            'Offering_Year' =>'2012',
            'Offering_Location' =>'WINTER',
            'Offering_Time' =>'08:30:00',
            'Faculty_No' =>'765-43-2109',
            'Offering_Days' =>'MW',
            ]);
        
        DB::table('offerings')->insert([
            'Offering_No' =>'5678',
            'Course_No' =>'IS480',
            'Offering_M' =>'BLM302',
            'Offering_Year' =>'2013',
            'Offering_Location' =>'WINTER',
            'Offering_Time' =>'10:30:00',
            'Faculty_No' =>'987-65-4321',
            'Offering_Days' =>'MW',
            ]);
            
        DB::table('offerings')->insert([
            'Offering_No' =>'5679',
            'Course_No' =>'IS480',
            'Offering_M' =>'BLM412',
            'Offering_Year' =>'2013',
            'Offering_Location' =>'SPRING',
            'Offering_Time' =>'15:30:00',
            'Faculty_No' =>'876-54-3210',
            'Offering_Days' =>'TTH',
            ]);
        
        DB::table('offerings')->insert([
            'Offering_No' =>'6666',
            'Course_No' =>'FIN450',
            'Offering_M' =>'BLM212',
            'Offering_Year' =>'2013',
            'Offering_Location' =>'WINTER',
            'Offering_Time' =>'10:30:00',
            'Faculty_No' =>'987-65-4321',
            'Offering_Days' =>'TTH',
            ]);
        
        DB::table('offerings')->insert([
            'Offering_No' =>'7777',
            'Course_No' =>'FIN480',
            'Offering_M' =>'BLM305',
            'Offering_Year' =>'2013',
            'Offering_Location' =>'SPRING',
            'Offering_Time' =>'13:30:00',
            'Faculty_No' =>'765-43-2109',
            'Offering_Days' =>'MW',
            ]);
        
        DB::table('offerings')->insert([
            'Offering_No' =>'8888',
            'Course_No' =>'IS320',
            'Offering_M' =>'BLM405',
            'Offering_Year' =>'2013',
            'Offering_Location' =>'SUMMER',
            'Offering_Time' =>'13:30:00',
            'Faculty_No' =>'654-32-1098',
            'Offering_Days' =>'MW',
            ]);
        
        DB::table('offerings')->insert([
            'Offering_No' =>'9876',
            'Course_No' =>'IS460',
            'Offering_M' =>'BLM307',
            'Offering_Year' =>'2013',
            'Offering_Location' =>'SPRING',
            'Offering_Time' =>'13:30:00',
            'Faculty_No' =>'654-32-1098',
            'Offering_Days' =>'TTH',
            ]);*/
    }
}
