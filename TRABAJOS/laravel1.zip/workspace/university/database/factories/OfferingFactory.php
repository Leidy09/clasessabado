<?php

use Faker\Generator as Faker;

$factory->define(App\Offering::class, function (Faker $faker) {
    return [
        //
    ];
});
