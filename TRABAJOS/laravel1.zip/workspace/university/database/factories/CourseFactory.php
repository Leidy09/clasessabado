<?php

use Faker\Generator as Faker;

$factory->define(App\Course::class, function (Faker $faker) {
    return [
        //
        'Course_No'=> $faker->text(10),
        'Course_Desc'=> $faker->text(900),
        'CRS_Units'=>$faker->number(10),
        
    ];
});
