<?php

use Faker\Generator as Faker;

$factory->define(App\Enrrolloment::class, function (Faker $faker) {
    return [
        //
    ];
});
