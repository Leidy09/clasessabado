<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateStudentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('students', function (Blueprint $table) {
           $table->char('Student_No',11)->primary();
             $table->string('Student_LastName',30);
             $table->string('Student_FirstName',30);
             $table->string('Student_City',30);
             $table->char('Student_state',2);
             $table->char('Student_Zip',10);
             $table->char('Student_Major',6)->nullable();
             $table->char('Student_Class',3,2)->nullable();
             $table->decimal('Student_Gpa',3,2)->nullable();
             $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('students');
    }
}
