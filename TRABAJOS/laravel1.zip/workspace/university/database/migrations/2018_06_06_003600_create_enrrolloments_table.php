<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEnrrollomentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('enrrolloments', function (Blueprint $table) {
                    $table->integer('Offering_No');
            $table->char('Student_No',11); 
            $table->decimal('enrolloment_grade',3,2);
            $table->primary(['Offering_No','Student_No']);
            $table->foreign('Offering_No')->references('Offering_No')->on('offerings');
            $table->foreign('Student_No')->references('Student_No')->on('students');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('enrrolloments');
    }
}
