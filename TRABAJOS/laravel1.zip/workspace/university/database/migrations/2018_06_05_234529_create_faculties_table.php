<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFacultiesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('faculties', function (Blueprint $table) {
            $table->char('Faculty_No',11)->primary();
             $table->string('Faculty_Firstname',30);
             $table->string('Faculty_Lastname', 30);
             $table->string('Faculty_City',30);
             $table->char('Faculty_state',2);
             $table->char('Faculty_Zip',10);
             $table->char('Faculty_Rank',6)->nullable();
             $table->date('Faculty_HireDate',2)->nullable();
             $table->decimal('Faculty_Salary',10,2)->nullable();
             $table->char('Faculty_Supervisor',11)->nullable();
             $table->char('Faculty_Departament',6)->nullable();
             $table->timestamps();
});

                Schema::table('faculties',function (Blueprint $table){
        
        $table->foreign('Faculty_Supervisor')->references('Faculty_No')->on('faculties');
    

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('faculties');
    }
}
