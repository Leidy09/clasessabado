<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOfferingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('offerings', function (Blueprint $table) {
             $table->integer('Offering_No')->primary();
             $table->string('Offering_M',6);
             $table->integer('Offering_Year');
             $table->string('Offering_Location',30);
             $table->char('Offering_Time',10);
             $table->char('Faculty_No',11);
             $table->char('Offering_Days',4);
             $table->char('Course_No',11);
             $table->foreign('Faculty_No')->references('Faculty_No')->on('faculties');
             $table->timestamps();
        });
        
             Schema::table('offerings', function (Blueprint $table) {
             $table->foreign('Course_No')->references('Course_No')->on('courses');
            

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('offerings');
    }
}
