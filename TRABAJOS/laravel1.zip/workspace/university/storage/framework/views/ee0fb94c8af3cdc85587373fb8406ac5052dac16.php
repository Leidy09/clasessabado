<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
          <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
          
    <title>STUDENT</title>
    
</head>
<body>
            
    <form method="post" action="<?php echo e(action('StudentController@update', $Student_No)); ?>">  
        <?php echo csrf_field(); ?>
        <input type="hidden" name="_method" value="PUT"/>
        <div class="container">
            
            <h2>EDIT STUDENT</h2>
            
            <div class="control-label col-sm-2" >
                
                <label for="">Student_No°</label>
                <input type="text" name="studentno" class="form-control" disabled="disabled" value="<?php echo e($student->Student_No); ?>"/>
            
                <label for="">Student_LastName</label>
                <input type="text" name="lastname" class="form-control" value="<?php echo e($student->Student_LastName); ?>"/>
            
                <label for="">Student_Firstname</label>
                <input type="text" name="firstname" class="form-control" value="<?php echo e($student->Student_FirstName); ?>"/>
                
                <label for="">Student_City</label>
                <input type="text" name="city" class="form-control" value="<?php echo e($student->Student_City); ?>"/>
            
                <label for="">Student_state</label>
                <input type="text" name="state" class="form-control" value="<?php echo e($student->Student_state); ?>"/>
            
                <label for="">Student_Zip</label>
                <input type="text" name="zip" class="form-control" value="<?php echo e($student->Student_Zip); ?>"/>
            
                <label for="">Student_Major</label>
                <input type="text" name="major" class="form-control" value="<?php echo e($student->Student_Major); ?>"/>
            
                <label for="">Student_Class</label>
                <input type="text" name="class" class="form-control" value="<?php echo e($student->Student_Class); ?>"/>
                
                <label for="">Student_Gpa</label>
                <input type="text" name="class" class="form-control" value="<?php echo e($student->Student_Gpa); ?>"/>
                            
                <button type="Submit" class="btn btn-success">ENVIAR</button>
            </div>
        </div>
    </form>
    
</body>
</html>