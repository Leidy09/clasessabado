<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title>Document</title>
</head>
<body>
    <h2>LIST FACULTY</h2>
       <a href="<?php echo e(url('')); ?>" class="btn btn-primary">Crear estudiante</a>
        <?php echo csrf_field(); ?>
        <div class="container">
            <br>
            <table class="table table-striped ">
                <thead>
                    <tr>
                        <th>PERIODO</th>
                        <th>ACCIONES</th>
                    </tr>
                </thead>
        </div>
               <tbody>
                    <?php $__currentLoopData = $; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($['']); ?></td>     
                        <td><?php echo e($['']); ?></td>     
                        
                        
                        <td aling="rigth">
                            
                            <a href="<?php echo e()); ?>" class="btn btn-warning">UPDATE</a>
                        
                        </td>
                            
                        <td>
                            <form  action="<?php echo e(action('FacultyController@destroy', $faculty->Faculty_No)); ?>" method='post'>
        
                                
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="_method" value="DELETE"/>
                                <button class="btn btn-danger" type="submit">DELETE</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
            </table>
    </body>
</html>
    <table class="table table-striped">
	    	<thead>
	     	 <tr>
	        <th>PERIODO</th>
	        <th>ACCIONES</th>
	      	</tr>
		    </thead>
		    <tbody>
		    	 <tr>
		        <td></td>
		        <td><button class="btn btn-success" style="margin: 0 auto;">Actualizar</button></td>
		        <td><button class="btn btn-danger">Eliminar</button></td>
		      </tr>
		    </tbody>
  </table>
    
    
</body>
</html>