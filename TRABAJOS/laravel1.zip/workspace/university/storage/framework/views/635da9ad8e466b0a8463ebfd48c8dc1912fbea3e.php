<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
          
   
    <title>LIST COURSES</title>
</head>
<body>
      
        <?php echo csrf_field(); ?>
        <div class="container">
            <h2>COURSES</h2>
            <a href="<?php echo e(url('courses/create')); ?>" class="btn btn-primary">Crear Estudiante</a>
            <br>
            <table class="table table-striped ">
                <thead>
                    <tr>
                        <th>COURSES_N°</th>
                        <th>DESCRIPTION</th>
                        <th>UNITS</th>
                        <th>CREATED</th>
                        <th>UPDATE</th>
                        
                    </tr>
                </thead>
        </div>
               <tbody>
                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($course['Course_No']); ?></td>     
                        <td><?php echo e($course['Course_Desc']); ?></td>     
                        <td><?php echo e($course['CRS_Units']); ?></td>     
                        <td><?php echo e($course['created_at']); ?></td>     
                        <td><?php echo e($course['updated_at']); ?></td> 
                        <td aling="rigth">
                            
                            <a href="<?php echo e(action('CourseController@edit',$course['Course_No'])); ?>" class="btn btn-warning">UPDATE</a>
                            
                            <form action="<?php echo e(action('CourseController@destroy',$course->Course_No)); ?>" method='post'>
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="_method" value="DELETE"/>
                                <button class="btn btn-danger" type="submit">DELETE</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
            </table>
    </body>
</html>