<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
          
   
    <title>LIST STUDENTS</title>
</head>
<body>
     <h1>STUDENTS</h1>
     <a href="<?php echo e(url('students/create')); ?>" class="btn btn-primary">Crear estudiante</a>
        <?php echo csrf_field(); ?>
        <div class="container">
            <br>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Student_No°</th>
                        <th>Student_LastName</th>
                        <th>Student_FirstName</th>
                        <th>Student_City°</th>
                        <th>Student_state</th>
                        <th>Student_Zip</th>
                        <th>Student_Major</th>
                        <th>Student_Class</th>
                        <th>Student_Gpa</th>
                        <th>CREATED</th>
                        <th>UPDATE</th>
                        <th colspan="2">Acciones</th>
                    </tr>
                </thead>
        </div>
               <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($student['Student_No']); ?></td>     
                        <td><?php echo e($student['Student_LastName']); ?></td>     
                        <td><?php echo e($student['Student_FirstName']); ?></td>     
                        <td><?php echo e($student['Student_City']); ?></td>     
                        <td><?php echo e($student['Student_state']); ?></td>     
                        <td><?php echo e($student['Student_Zip']); ?></td>     
                        <td><?php echo e($student['Student_Major']); ?></td>     
                        <td><?php echo e($student['Student_Class']); ?></td>     
                        <td><?php echo e($student['Student_Gpa']); ?></td> 
                        <td><?php echo e($student['created_at']); ?></td>     
                        <td><?php echo e($student['updated_at']); ?></td> 
                    
                     <td aling="rigth">
                            
                            <a href="<?php echo e(action('StudentController@edit', $student->Student_No)); ?>" class="btn btn-warning">UPDATE</a></td>
                            
                          <td><form  action="<?php echo e(action('StudentController@destroy', $student-> Student_No)); ?>" method='post'>
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="_method" value="DELETE"/>
                                <button class="btn btn-danger" type="submit">DELETE</button>
                            </form>
                        </td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
            </table>
    </body>
</html>