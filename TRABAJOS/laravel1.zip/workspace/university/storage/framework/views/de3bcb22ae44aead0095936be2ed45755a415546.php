<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
          
   
    <title>LIST FACULTY</title>
</head>
<body>
       <h2>LIST FACULTY</h2>
       <a href="<?php echo e(url('faculties/create')); ?>" class="btn btn-primary">Crear estudiante</a>
        <?php echo csrf_field(); ?>
        <div class="container">
            <br>
            <table class="table table-striped ">
                <thead>
                    <tr>
                        <th>Faculty_No°</th>
                        <th>Faculty_FirstName</th>
                        <th>Faculty_LastName</th>
                        <th>Faculty_City</th>
                        <th>Faculty_state</th>
                        <th>Faculty_Zip</th>
                        <th>Faculty_Rank</th>
                        <th>Faculty_HireDate</th>
                        <th>Faculty_Salary</th>
                        <th>Faculty_Supervisor</th>
                        <th>Faculty_Departament</th>
                        <th>CREATED</th>
                        <th>UPDATE</th>
                        <th colspan="2">Acciones</th>
                        
                    </tr>
                </thead>
        </div>
               <tbody>
                    <?php $__currentLoopData = $faculties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($faculty['Faculty_No']); ?></td>     
                        <td><?php echo e($faculty['Faculty_FirstName']); ?></td>     
                        <td><?php echo e($faculty['Faculty_LastName']); ?></td>     
                        <td><?php echo e($faculty['Faculty_City']); ?></td>     
                        <td><?php echo e($faculty['Faculty_state']); ?></td>
                        <td><?php echo e($faculty['Faculty_Zip']); ?></td>     
                        <td><?php echo e($faculty['Faculty_Rank']); ?></td>     
                        <td><?php echo e($faculty['Faculty_HireDate']); ?></td>     
                        <td><?php echo e($faculty['Faculty_Salary']); ?></td>                     
                        <td><?php echo e($faculty['Faculty_Supervisor']); ?></td>     
                        <td><?php echo e($faculty['Faculty_Departament']); ?></td>     
                        <td><?php echo e($faculty['created_at']); ?></td>     
                        <td><?php echo e($faculty['updated_at']); ?></td> 
                        
                        <td aling="rigth">
                            
                            <a href="<?php echo e(action('FacultyController@edit', $faculty->Faculty_No)); ?>" class="btn btn-warning">UPDATE</a>
                        
                        </td>
                            
                        <td>
                            <form  action="<?php echo e(action('FacultyController@destroy', $faculty->Faculty_No)); ?>" method='post'>
        
                                
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="_method" value="DELETE"/>
                                <button class="btn btn-danger" type="submit">DELETE</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
            </table>
    </body>
</html>