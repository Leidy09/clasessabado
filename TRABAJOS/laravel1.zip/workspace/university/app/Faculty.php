<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Faculty extends Model
{
     protected $table='faculties';
     protected $primaryKey='Faculty_No';
    protected $fillable=[
        
        'Faculty_No',
        'Faculty_Firstname',
        'Faculty_Lastname',
        
        'Faculty_City',
        'Faculty_state',
        'Faculty_Zip',
        
        'Faculty_Rank',
        'Faculty_HireDate'
        
        ];

}
