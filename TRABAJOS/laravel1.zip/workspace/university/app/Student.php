<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    //
    protected $table='students';
    protected $primaryKey='Student_No';
    protected $fillable=[
        
        'Student_No',
        'Student_LastName',
        'Student_FirstName',
        
        'Student_City',
        'Student_state',
        'Student_Zip',
        
        'Student_Major',
        'Student_Class'
        
        ];

}
