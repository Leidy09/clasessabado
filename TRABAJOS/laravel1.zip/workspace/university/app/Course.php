<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Course extends Model
{
    protected $table='courses';
    protected $primaryKey = 'Course_No';
    protected $keyType = 'string';
    protected $incrementring = false;
    protected $fillable=[
        'Course_No',
        'Course_Desc',
        'CRS_Units',
        ];
}
