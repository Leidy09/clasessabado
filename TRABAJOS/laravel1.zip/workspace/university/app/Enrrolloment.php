<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Enrrolloment extends Model
{
    //
}
