<?php

namespace App\Http\Controllers;

use App\Faculty;
use Illuminate\Http\Request;

class FacultyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $faculties = Faculty::all();
        return view('faculties.index',compact('faculties'));
    
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('faculties.create');
         
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $faculties =new Faculty();
        $faculties->Faculty_No = $request->get('facultyno');
        $faculties->Faculty_Firstname = $request->get('firstname');
        $faculties->Faculty_Lastname = $request->get('lastname');
        $faculties->Faculty_City = $request->get('city');
        $faculties->Faculty_state = $request->get('state');
        $faculties->Faculty_Zip = $request->get('zip');
        $faculties->Faculty_Rank = $request->get('rank');
        $faculties->Faculty_HireDate = $request->get('hiredate');
        $faculties->Faculty_Salary = $request->get('salary');
        $faculties->Faculty_Supervisor = $request->get('supervisor');
        $faculties->Faculty_Departament = $request->get('departament');
        
        $faculties->save();
        return redirect('faculties');
        
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Faculty  $faculty
     * @return \Illuminate\Http\Response
     */
    public function show(Faculty $faculty)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Faculty  $faculty
     * @return \Illuminate\Http\Response
     */
    public function edit($Faculty_No)
    {
        //
        //dd($faculty);
        $faculties = Faculty::find($Faculty_No);
        return view ('faculties.index',compact('faculties','Faculty_No'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Faculty  $faculty
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $Faculty_No)
    {
        //
        $faculties =Faculty::find($Faculty_No);
        //dd($faculty);
        
        
        $faculties->Faculty_Firstname = $request->get('firstname');
        $faculties->Faculty_Lastname = $request->get('lastname');
        $faculties->Faculty_City = $request->get('city');
        $faculties->Faculty_state = $request->get('state');
        $faculties->Faculty_Zip = $request->get('zip');
        $faculties->Faculty_Rank = $request->get('rank');
        $faculties->Faculty_HireDate = $request->get('hiredate');
        $faculties->Faculty_Salary = $request->get('salary');
        $faculties->Faculty_Supervisor = $request->get('supervisor');
        $faculties->Faculty_Departament = $request->get('departament');
       
       $faculty->save();
       return redirect('faculties');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Faculty  $faculty
     * @return \Illuminate\Http\Response
     */
    public function destroy($Faculty_No )
    {
        $faculty = Faculty::find($Faculty_No);
        //dd($faculty);
        $faculty->delete();
        
        return redirect('faculties');
    }
}
