<?php

namespace App\Http\Controllers;

use App\Student;
use Illuminate\Http\Request;

class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $students= Student::all();
        
        return view ('students.index',compact('students'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('students.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $student = new Student();
        $student->Student_No=$request->get('studentno');
        $student->Student_LastName=$request->get('lastname');
        $student->Student_FirstName=$request->get('firstname');
        $student->Student_City=$request->get('city');
        $student->Student_State=$request->get('state');
        $student->Student_Zip=$request->get('zip');
        $student->Student_Major=$request->get('major');
        $student->Student_Class=$request->get('class');
        $student->Student_Gpa=$request->get('gpa');

        $student->save();
        return redirect ('students');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function show(Student $student)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function edit($Student_No)
    {
        //
        //dd($Student_No);
        $student = Student::find($Student_No);
        return view ('students.edit', compact('student','Student_No'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $Student_No)
    {
        //
        $student= Student::find($Student_No);
        //dd($course);
        
        $student->Student_LastName=$request->get('lastname');
        $student->Student_Firstname=$request->get('firstname');
        $student->Student_City=$request->get('city');
        $student->Student_State=$request->get('state');
        $student->Student_Zip=$request->get('zip');
        $student->Student_Major=$request->get('major');
        $student->Student_Class=$request->get('class');
        $student->Student_Gpa=$request->get('gpa');

        $student->save();
        return redirect ('students');
        
        
                
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function destroy($Student_No)
    {
        //
        $student= Student::find($Student_No);
        //dd($student);
        $student->delete();
        
        return redirect ('students');
        
    }
}
