<?php

namespace App\Http\Controllers;

use App\Course;
use Illuminate\Http\Request;

class CourseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
      //return view('courses.create');
        $courses = Course::all();
        return view('courses.index',compact('courses'));
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('courses.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $courses = new Course();
        
        $courses->Course_No = $request->get('courseno');
        $courses->Course_Desc=$request->get('desc');
        $courses->CRS_Units=$request->get('units');
    
        $courses->save();
        return redirect('courses');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\courses  $courses
     * @return \Illuminate\Http\Response
     */
    public function show(courses $courses)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Course  $courses
     * @return \Illuminate\Http\Response
     */
    public function edit($Course_No)//$courseNo
    {
        //dd($Course_No);
        //
        $course = Course::find($Course_No);
        //dd($Course_No);
        return view('courses.edit', compact('course','Course_No'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $Course_No)
    {
        //
        $course=Course::find($Course_No);// crea un modelo con los datos correspondientes a la ok
       // dd($course);
        
        $course->Course_Desc=$request->get('desc');//cambia el valor de un campo en el modelo
        $course->CRS_Units=$request->get('units');//cambia el valor de un campo en el modelo
        
        
        $course->save();
        return redirect ('courses');// redirige la ruta a course  que  muestra los registros de la tabla 
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function destroy($Course_No)
    {
        //
        
        $course = Course::find($Course_No);
        //dd($course);
        $course->delete();
        
        return redirect('courses');
    }
}
