<?php
use Class_pdo\User;

if (isset($_GET['id']) && !empty($_GET['id'])) {
    require_once('../Class/User.php');
    $id = $_GET['id'];
    $user = new User();
    $resultUser = $user->getUser($id);
    
}else{
    header('location:listuser.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add user</title>
</head>
<body>
    <h1>Update user</h1>
    <a href="listuser.php">back</a>
    <form action="../controller/UpdateUser.php" method="post">
        <input type="hidden" name="id" required value="<?php echo $resultUser['id']; ?>" />
        <label for="name">Name</label><input type="text" name="name" value="<?php echo $resultUser['name']; ?>" id="name" required />
        <label for="phone">Phone</label><input type="number" name="phone" id="phone" required value="<?php echo $resultUser['phone']; ?>" />
        <input type="submit" value="Submit"/>
    </form>
</body>
</html>