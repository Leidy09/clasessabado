<?php
 use class_pdo\User;
 
    if (isset($_POST) &&  !empty($_POST)) {
        require_once('../Class/User.php');
        $name= $_POST['name'];
        $phone= $_POST['phone'];
        
        
        $user = new User ();
         $result = $user->addUser($name, $phone);
        if ($result) {
            echo "<span> Succes registrer</span>";
        }else{
            echo "<span> Gronw registrer/span>";
        }
}

?>


<!DOCTYPE html>
    <html>
        <head>
            <meta charset="uft-8">
            <meta name="viewport" content="width-device-width, initial-scale=1.0">
            <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add user</title>
</head>
<body>
    <h1>Add user</h1>
    <a href="../">back</a>
    <form action="adduser.php" method="post">
        <label for="name">Name</label><input type="text" name="name" id="name" required/>
        <label for="phone">Phone</label><input type="number" name="phone" id="phone" required />
        <input type="submit" value="Submit"/>
    </form>
</body>
</html>