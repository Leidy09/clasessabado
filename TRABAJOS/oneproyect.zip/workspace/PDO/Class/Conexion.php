<?php
namespace class_pdo;

class Conexion extends \PDO
{
    public $typeDB = 'mysql';
    public $hostDB = 'localhost';
    public $nameDB = 'crud_pdo';
    public $userDB = 'root';
    public $passwordDB = '';
    
    public function __construct()
    {
        try {
            parent::__construct("$this->typeDB: host=$this->hostDB; dbname=$this->nameDB", $this->userDB, $this->passwordDB);
            $this->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);    
        } catch (Exception $e) {
            echo "Error en base de datos: $e->getMessage();";
        }
        
    }
}