<?php

use class_pdo\User;
if(isset($_POST) && !empty($_POST)){
    require_once("../class/User.php");
    $user = new User();
    $id = $_POST['id'];
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $user->updateUser($id, $name, $phone);
    header('location:../views/listuser.php');
}