<?php   

phpinfo();
