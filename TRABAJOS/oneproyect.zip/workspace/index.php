 <?php
include_once 'vehicle/Vehicle.php';
include_once  'vehicle/Car.php';
include_once 'vehicle/Truck.php';
include_once 'vehicle/Motorcycle.php';
include_once 'vehicle/ToyCar.php';

use vehicle\{Car,Truck,Motorcycle,Vehicle,ToyCar};
//this para objetos self para clases 


 echo"<hr>";
 echo"<h2>OBJETO CAR</h2>";

 $Car1=new Car("Leidy");//instancia un objeto no le da valor a unb objeto
 $Car1->location();
 $Car1->encendido();
 $Car1->apagado();
 $Car1->move();
 echo "El propietario es ".$Car1->getOwner();


$Car1 -> stop();
$Car1->color="Red";
echo"<div> El color del vehiculo es $Car1->color</div>";
echo"</hr>"; 



echo"<hr>";
echo"<h2>OBJETO TRUCK</h2>";
$truck1 = new Truck("Laura","Magenta");
echo"<div>El numero de vehiculos es:" . Vehicle::getCuentaVehicle()."</div>";
echo "<div>El color del truck es $truck1->color</div>";
echo"</hr>";


echo"<hr>";
echo"<h2>OBJETO MOTORCYCLE</h2>";
echo"<div>El numero de vehiculos es:" . Vehicle::getCuentaVehicle()."</div>";


$Motorcycle = new Motorcycle("Lina","Black","FFU07C");
$Motorcycle->setplaca("FND04D");
echo"<div>La nueva placa es ".$Motorcycle->getplaca()."</div>";

$Motorcycle-> move();
$Motorcycle-> startEngine();
$Motorcycle->acelera();
$Motorcycle->frena();
$Motorcycle->direccionales();
$Motorcycle->pito();
echo"<hr>";

$toyCar1 = new ToyCar("Tiago");
try {
 
  $toyCar1->move();
  
} catch (Exception $e ) {
 
 echo"<div>EL carro sin motor no prende, debes empujarlo con la mano</div>";
}
echo"<hr>";


//-------------------------------------------------------------------------------EJEMPLOS-------------------------------------------------------------------------------------

//  //Clase CAR 
 
//  class Car{
//     public $owner;//scope Alcance
        
//         function move(){//Metodos
//             echo"Carro en moviento";
//         }
//  }
// $car1= new Car(); //llamar un objeto
// $car1->move(); //->arrow 
// $car1->owner= "Leidy";// variable publica
// echo "El propietario es". $car1->owner;

 
// $car2= new Car(); //llamar un objeto
// $car2->move(); //->arrow 
// $car2->owner= "Leidy";// variable publica
// echo "El propietario es". $car2->owner;

// $car3= new Car(); //llamar un objeto
// $car3->move(); //->arrow 
// $car3->owner= "Leidy";// variable publica
// echo "El propietario es". $car3->owner;



// //CLASE PRIVADA 
 
//  class CAR{
//     private $owner;//scope Alcance
        
//         function move(){//Metodos
//              echo"<div>Carro en moviento</div>";
//         }
        
//             function setOwner($owner){
//                 $this->owner=$owner;
//              }
             
//                 function getOwner(){
//                     return $this->owner;
//                 }

     
//  }
//  $Car1=new CAR("");
//  $Car1->move();
//  $Car1 ->setOwner("Leidy");
//  echo "El propietario es ".$Car1->getOwner();


//CLASE PRIVADA camel case siempre inicia con mayuscula 
 









