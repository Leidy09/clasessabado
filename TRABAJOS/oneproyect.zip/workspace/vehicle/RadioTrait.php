<?php
namespace Vehicle;

trait RadioTrait{
     function encendido(){
          echo"<div>La radio esta encendida </div>";
     }
     function apagado(){
         echo"<div>La radio esta apagada </div>";
     }
}