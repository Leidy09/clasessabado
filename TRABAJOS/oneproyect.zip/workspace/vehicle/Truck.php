<?php
namespace vehicle;
  require_once 'Vehicle.php';
  require_once 'GPSTrait.php';

  
     class Truck extends Vehicle{
        public $color;
        
        use GPSTRait , RadioTrait;
        
            function __construct($owner, $color){
                $this->color = $color;
                    parent::__construct($owner);
                        echo "sobreescribi el constructor de truck";
                        
                    }
                        function startEngine(){
                            echo"Motor Encendido";
                        }
                        function stop(){
                            echo"<div>El camion se detuvo</div>";
                        }
                    
                }
                
             
  

