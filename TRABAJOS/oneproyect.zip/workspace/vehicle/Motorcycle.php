<?php
namespace vehicle;
  require_once'Vehicle.php';
  require_once 'ManubrioInterface.php';
  
  class Motorcycle extends Vehicle implements ManubrioInterface{
    private $placa;
                         
         function move(){//
         $this->startEngine();
         echo"<div>Vehiculo en moviento</div>";
          }
                     
            function __construct($owner,$color,$placa){
            parent::__construct($owner);
            $this->placa=$placa;
            echo"<div>El dueño de la moto es $owner</div>";
            echo"<div>El color de la moto es $color </div>";
            echo"<div>La placa de la moto es  $placa</div>";
            $this->move();
             }
              
              
            function setplaca($placa){
                $this->placa=$placa;
            }
            
            function getplaca(){
                return $this->placa;
           }
                     
            function startEngine(){
                echo"<div>Motor Encendido</div>";
            }
                       
            function acelera(){
                echo"<div>La motocicleta aumenta la velocidad</div>";
             }
            function frena(){
                 echo"<div>La motocicleta disminuyo la velocidad</div>";
            }
             function direccionales(){
                echo"<div> La motocicleta cambia de direccionales </div>";
            }
            function pito(){
                echo"<div>La motocicleta pita</div>";
                            }
                         
                    
     }
     
     
  
          

