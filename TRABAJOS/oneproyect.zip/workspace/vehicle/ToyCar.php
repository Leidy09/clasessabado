<?php

namespace Vehicle;
require_once'Vehicle.php';

class ToyCar extends Vehicle{
    
    function move(){
        $this-> startEngine();
        parent::move();
        }
    function startEngine(){    
        throw new \Exception("Este carro no tiene motor");
    }
}
