<?php

 namespace vehicle;
 
 interface TimonInterface{
     function turnLeft();
     function turnRigth();
 }