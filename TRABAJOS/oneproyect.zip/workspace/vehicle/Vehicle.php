<?php
 namespace Vehicle;
 abstract class Vehicle{ 
  
    
    private  static $cuentaVehicles=0;
    private $owner;//scope Alcance
        
    function __construct ($owner){//  cosntructor  2guiones al piso metodo magico  siempre con la misma sintaxis
    //$this->cuentaVehicles++ objeto
    self::$cuentaVehicles++;
    $this->owner=$owner;
    echo"<div>El cosntructor de el vehiculo de $this->owner funciona </div>";
    }
 
 public abstract function startEngine();
  
    public static function getCuentaVehicle(){
        // return $cuentaVehicles; //public static
            return self:: $cuentaVehicles;
    }
    
        function __destruct(){//Destructor 
            echo"<div>Vehiculo de $this->owner se destruyo</div>";
        }
        function move(){//Metodos
            echo"<div>Vehiculo en moviento</div>";
        }
        function setOwner($owner){
            $this->owner=$owner;
        }
        function getOwner(){
            return $this->owner;
        }
        function stop(){ // para realizar una funcion 
            echo"El vehiculo se detuvo";
        }
           
}