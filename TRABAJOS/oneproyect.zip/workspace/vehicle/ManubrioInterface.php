<?php
namespace vehicle;

 interface ManubrioInterface{
      function acelera();
      function frena();
      function direccionales();
      function pito();
      
      
      
      
 }