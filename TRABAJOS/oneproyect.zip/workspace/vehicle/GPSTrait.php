<?php
 namespace Vehicle;
 
 trait GPSTrait{
     function location(){
         echo"<div>Vehiculo localizado </div>";
  
     }
      function coordenadas(){
          
          echo"<div>LATITUD 76,8967 LONGITUD 3,673421</div>";
      }
 }