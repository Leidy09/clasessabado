<?php
namespace vehicle;
interface PedalesInterface{
    function acelera();
    function frena();
    function embrage();
    
}