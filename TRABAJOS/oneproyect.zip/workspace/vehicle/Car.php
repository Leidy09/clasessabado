<?php
namespace vehicle;
  require_once 'Vehicle.php';
  require_once'TimonInterface.php';
  require_once'PedalesInterface.php';
  require_once 'GPSTrait.php';
  require_once'ToyCar.php';
  require_once'RadioTrait.php';
  
  
        class Car extends Vehicle implements TimonInterface, PedalesInterface{
           
           use GPSTrait,RadioTrait; 
           
            function move (){
                 $this->startEngine();
                 echo"<div>Este carrazo anda bacanisimo</div>";
            }
            function stop(){//sobre escribir un metodo
                echo"<div>El carro se detuvo</div>";
            }
            function startEngine(){
                echo"Motor encendido";
            }
            
            function turnLeft(){
                echo"El carro gira a la izquierda";
            }
            
            function turnRigth(){
                echo"El carro gira a la derecha";
            }  
            
            function acelera(){
                "El carro aumento la velocidad";
            }
            
            function frena(){
                echo"El carro disminuyo la velocidad";
            }
            
            function embrage(){
                echo" El carro puede realizar el cambio de velocidad";
            }
  }
    
  