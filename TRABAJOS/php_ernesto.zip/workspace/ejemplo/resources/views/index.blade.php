@extends('Ejemplo.plantilla.main')
@section('titulo')@endsection
@section('title')@endsection
    
    @section('content')@endsection
    