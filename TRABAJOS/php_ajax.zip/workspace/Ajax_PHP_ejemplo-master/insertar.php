<?php
class UsuarioModel{

	private $pdo;
	public function __CONSTRUCT(){
		try {
		
			$this->pdo = new PDO('mysql:host=localhost;dbname=bd_prueba','root','');
			$this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		
		} catch (Exception $e) {
		
			die($e->getMessage());
			}

		}
	
	
	public function Listar()
	{
		try 
		{
			$result =array();
			$sl = $this->pdo->prepare("SELECT * FROM personas");
			$sl->execute();

			foreach($sl->fetchAll(PDO::FETCH_OBJ) as $r)
			 {
				$user= new Usuario();
				$user->__SET('id',$r->id);
				$user->__SET('identificacion',$r->identificacion);
				$user->__SET('nombres',$r->nombres);
				$user->__SET('apellidos',$r->apellidos);
				$user->__SET('celular',$r->celular);
				$user->__SET('email',$r->email);
				
				 $result[]= $user;


			}


			return $result;
		}
		 
		catch (Exception $e)
		 {
			
			die($e->getMessage());

		}
		}
	
		 function obtener($id){

		 	try {
		 		
		 		$sl= $this->pdo->prepare("SELECT * FROM personas WHERE id = ?
		 		");

		 		$sl->execute(array($id));
		 		$r = $sl->fetch(PDO:: FETCH_OBJ) ;

		 		$user= new Usuario();

		 		$user->$__SET('id',$r->id);
				$user->$__SET('identificacion',$r->identificacion);
				$user->$__SET('nombres',$r->Nombres);
				$user->$__SET('apellidos',$r->Apellidos);
				$user->$__SET('celular',$r->Celular);
				$user->$__SET('email',$r->Email);


				return $user;

		 	} catch (Exception $e) {
		 		
		 		die($e->getMessage());
		 	}
		 }

		 function Eliminar($id){

		 	try {
		 		
		 		$sl=$this->pdo->prepare("DELETE FROM personas WHERE id = ?");
		 		$sl->execute(array($id));

		 	} catch (Exception $e) {

		 		die($e->getMessage());
		 		
		 	}
		 }

		 function Actualizar (Usuario $data){

			try {
				
				$sql= "UPDATE personas SET 

					
					identificacion =?
					nombres= ?,
					apellidos = ?
					celular =?
					email =?
					WHERE id =?";

				$this->pdo->prepare($sql)->execute(array(
					$data->__GET('identificacion'),
					$data->__GET('nombres'),
					$data->__GET('apellidos'),
					$data->__GET('celular'),
					$data->__GET('email'),
					$data->__GET('id')
					)
				);

			} catch (Exception $e) {
				
				die($e ->getMessage());
			}
		}

		 function Registrar(Usuario $data){

			try {
				
				$sql ="INSERT INTO personas VALUES (null,?,?)";

				$this->pdo->prepare($sql)->execute(array(				

				$data->__GET('identificacion'),
					$data->__GET('nombres'),
					$data->__GET('apellidos'),
					$data->__GET('celular'),
					$data->__GET('email')	
					)
				);				

			} catch (Exception $e) {
				
				die($e->getMessage());	
			}
		}
	}


 ?>

<?php // Modelo
// include("config.php");
// $res = array();
// $res["res"] = "no";
// $sql= "INSERT INTO personas(identificacion,name,apellidos,phone, email) " ;
// $sql.= " VALUES('".$_POST['txtidentificacion']."','".$_POST['txtNombres']."',";
// $sql.= "'".$_POST['txtApellidos']."','".$_POST['txtCelular']."','".$_POST['txtEmail']."')";

// $rs = mysql_query($sql);

// if(!$rs) {
// 	$res["msj"] = "Error al intentar insertar ".mysql_error();
// } else {
// 	$res["res"] = "si";
// 	$res["msj"] = "Registro insertado";
// }
// echo json_encode($res);
// ?> ?>



