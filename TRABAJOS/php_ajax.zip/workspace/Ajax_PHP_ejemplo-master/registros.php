<?php 

class Usuario {

  private $id;
  public $identificacion;
  public $Nnmbre;
  public $apellidos;
  public $celular;
  public $email;

  public function __GET($k){return $this->$k;}
  public function __SET($k, $v){return $this->$k = $v; }

}

 ?>


