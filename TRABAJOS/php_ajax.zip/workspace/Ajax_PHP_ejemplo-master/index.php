<?php 
require_once'registros.php';
require_once'insertar.php';

//Logica 

$user = new Usuario();
$model = new  UsuarioModel();
//faltaba

if(isset($_POST['guardar'])){
    $user->__SET('identificacion',$_POST['identificacion']);
    $user->__SET('Nombres', $_POST['Nombres']);
    $user->__SET('Apellidos',$_POST['Apellidos']);
    $user->__SET('Celular', $_POST['Celular']);
    $user->__SET('Email',$_POST['Email']);
    $model->Registrar($user);
} 
if(isset($_POST['actualizar'])){
    $user->__SET('identificacion',$_POST['identificacion']);
    $user->__SET('Nombres', $_POST['Nombres']);
    $user->__SET('Apellidos',$_POST['Apellidos']);
    $user->__SET('Celular', $_POST['Celular']);
    $user->__SET('Email',$_POST['Email']);
    $model->Actualizar($user);
}
if(isset($_POST['borrar'])){    
    $model->Eliminar($_POST['id']);   
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="viewport" http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="style.css">
   
<title>CRUD</title>
<script type="text/javascript" language="javascript" src="jquery-3.3.1.min.js"  ></script>
<script type="text/javascript" language="javascript">

	function mostrar(usuarioid){
        var identificacionid = "identid" + usuarioid;
        var nombreid = "nameid" + usuarioid;
        var Apellidoid = "apeid" + usuarioid;
        var telefonoid = "telid" + usuarioid;
        var Emailid = "Emid" + usuarioid;
        
         var identificacionDelUsuario = document.getElementByid(identificacionid).innerHTML;       
        var nombreDelUsuario = document.getElementByid(nombreid).innerHTML;
        var apellidoDelUsuario = document.getElementByid(Apellidoid).innerHTML;
        var telefonoUsuario = document.getElementByid(telefonoid).innerHTML;
        var emailDelUsuario = document.getElementByid(Emailid).innerHTML;                
        
        document.getElementByid("idInput").value = usuarioid;            
        document.getElementByid("identInput").value = identificacionDelUsuario;
        document.getElementByid("nomInput").value = nombreDelUsuario;
        document.getElementByid("apeInput").value = apellidoDelUsuario;
        document.getElementByid("telInput").value = telefonoUsuario;
        document.getElementByid("emaInput").value = emailDelUsuario;
                   
        document.getElementByid("borrar").style.display = "block";
        document.getElementByid("guardar").disabled = "true";
        document.getElementByid("actualizar").style.display = "block";        
    }   
$(document).ready(function(e) {
	
	$("#btnEnviar").click(function() {
		
		if( $("#txtidentificacion").val().length == 0 ) {
		alert("Debes ingresar la identificación");
 		} else if( $("#txtNombres").val().length == 0 ) {
			alert("Debes ingresar tus nombres");
 		} else if( $("#txtApellidos").val().length == 0 ) {
 			alert("Debes ingresar tus apellidos");
 		} else if( $("#txtCelular").val().length == 0 ) {
 			alert("Debes ingresar tu celular");
 		} else if( $("#txtEmail").val().length == 0 ) {
 			alert("Debes ingresar tu email");
 		} else {
		
 			$.ajax({
 			  url: "insertar.php",
 			  type: 'post',
 			  data: $("#frmDatos").serialize(),
 			  dataType: 'json',
 			  success: function(data) {
 				if (data.res == "si") {
 					alert(data.msj);
 					  $("#cargaDeDatos").load('personas.php');
 				} else {
 					alert(data.msj);
 				}
 			  },
 			  error: function() {
 				alert( "Registro no guardado" );
 			  }
 			});
 		}
 		return false;
 	});
	

 });
</script>
<header>
  
</head>
 <body > 	
 			<header>
               <div class="container">
                    <h2>REGISTRO DE USUARIOS</h2>
                </div>
            </header>       
     
    <div class="container">

        <section class=" main row">

        	<form id="frmDatos" name="frmDatos" method="post" action="index.php">

			<table class=" table" width="247" border="0" style="" >
			    <tr style="">
			      <td width="87" class="lead text-succes">identificación</td>
			      <td width="144"><input type="text" name="txtidentificacion" id="txtidentificacion" class="form-control" /></td>
			    </tr>
			</table>

			<table class=" table" width="247" border="0" style="" >
			    <td width="87" class="lead text-succes">Nombres</td>
			      <td width="144"><input type="text" name="txtNombres" id="txtNombres" class="form-control" /></td>
			    </tr>
			</table>

			    <table class=" table table-striped" width="247" border="0" style="" >
			    <tr style="">
			      <td width="87" class="lead text-succes">Apellidos</td>
			      <td width="144"><input type="text" name="txtApellidos" id="txtApellidos" class="form-control" /></td>
			    </tr>
			</table>


			    <table  class=" table" width="247" border="0" style="" >
			    <tr style="">
			      <td width="87" class="lead text-succes">Celular</td>
			      <td width="144"><input type="text" name="txtCelular" id="txtCelular" class="form-control" /></td>
			    </tr>
			</table>

			    <table class=" table"  width="247" border="0" style="" >
			    <tr style="">
			      <td width="87" class="lead text-succes">Email</td>
			      <td width="144"><input type="text" name="txtEmail" id="txtEmail" class="form-control" /></td>
			    </tr>

			     <td>&nbsp;</td>
			     <td><input type="submit" name="btnEnviar" id="btnEnviar" value="Enviar" /></td>

			    <button id="actualizar" style="display: none" name="actualizar" class="btn btn-primary">Actualizar</button>

                <button id="borrar" style="display: none" name="borrar" class=" btn btn-primary">Borrar</button>
    			
  			</table>
			</form>

<br />
<div id="cargaDeDatos">
  
</div>
</section>
</div>
                 <div class="container">

                    <table class="table  table-strped table-bordered table-hover">
                    
                        <thead>
                            
                            <tr>
                                <th>ID</th>
                                <th >idENTIFICACION</th>
                                <th >NOMBRES</th>
                                <th>APELLidOS</th>
                                <th>CELULAR</th>
                                <th>EMAIL</th>
                            </tr>
                        </thead>

                    <?php foreach($model->Listar() as $r){ ?>
                    
                        <tr class="active">
                             
                               
                            <td><?php echo '<span id="'.$r->__GET("id").'">'.$r->__GET("id").'</span>'; ?></td>
                            <td><?php echo '<span id="identid'.$r->__GET("id").'">'.$r->__GET('identificacion').'</span>'; ?></td>
                            <td><?php echo '<span id="nameid'.$r->__GET("id").'">'.$r->__GET('Nombres').'</span>'; ?></td>
                            <td><?php echo '<span id="apeid'.$r->__GET("id").'">'.$r->__GET('Apellidos').'</span>'; ?></td>
                            <td><?php echo '<span id="telid'.$r->__GET("id").'">'.$r->__GET('Celular').'</span>';?></td>
                            <td><?php echo '<span id="Emid'.$r->__GET("id").'">'.$r->__GET('Email').'</span>'; ?></td>                            
                            <td>
                                
                                <a href="#" id="<?php echo $r->__GET('id') ?>" onclick="mostrar(this.id)">Editar</a>
                            </td>                            
                        </tr>

                    <?php } ?>

                    </table> 

                </div>

        <script src="js/JQuery.js"></script>
        <script src="js/bootstrap.min.js"></script>
    

    </body>
 </html>