# crud-apmy
CRUD con AJAX, PHP y MySQL

Para poder ejecutar correctamente el ejemplo debes cargar el contenido del archivo schema.sql a tu base de datos.

```
mysql -uroot -h127.0.0.1 < crud-apmy/schema.sql
```
### Leer articulo
http://evilnapsis.com/2016/10/03/crud-con-ajax-php-y-mysql/

### Copyleft
Evilnapsis 2016