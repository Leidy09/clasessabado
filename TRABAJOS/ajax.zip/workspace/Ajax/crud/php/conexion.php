<?php
$host="localhost";
$user="root";
$password="";
$db="crud2";
$con = new mysqli($host,$user,$password,$db);

?>