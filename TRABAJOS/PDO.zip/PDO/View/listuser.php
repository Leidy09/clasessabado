<?php
    require_once '../Class/User.php';
    use class_pdo\User;
    $users = new User();
    
    
    if(isset($_GET) && !empty($_GET['id'])){
        $return = $users->deleteUser($_GET['id']);
        if($return){
            echo "Successful deleting";
        }
    }
    if(isset($_GET['actualizar'])){
    $user->__SET('ID', $_POST['ID']);
    $user->__SET('Nombre', $_POST['Nombre']);
    $user->__SET('Telefono', $_POST['Telefono']);
    $model->Actualizar($user);
    
    }
        
    $listUsers = $users->getUsers();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>LIST USERS</title>
</head>
<body>
    <script type="text/javascript" src="">
        function update(Update){
        var nameid = "name" + Update;
        var phoneid = "phone" + Update;
            
            var id= document.getElementById(id).innerHTML;
            var nameid= document.getElementById(nameid).innerHTML;
            var phoneid= document.getElementById(phoneid).innerHTML;
            
            
        }
        
        
        
    </script>
     <h1>Lists Users</h1>
     <a href="../">back</a>
     
         <table>
             <thead>
                 <tr>
                     <td>ID</td>
                     <td>NAME</td>
                     <td>PHONE</td>
                 </tr>
             </thead>
             
             <tbody>
                <?php 
                foreach ($listUsers as $user){
                    
                    ?>
                
                 <tr>
                   <td><?php echo $user['id'];?></td>
                   <td><?php echo $user['name'];?></td>
                   <td><?php echo $user['phone'];?></td>
                   <td><a href="listuser.php?id=<?php echo $user['id']?>">Eliminar</a></td>
                   <td><a href="listuser.php?id=<?php echo $user['id']?>">Actualizar</a></td>
                
                
                 </tr>
               <?php }?>
           
                 
                 </tr>
              
    
             </tbody>
         </table>
         
         
     </body>
</html>


