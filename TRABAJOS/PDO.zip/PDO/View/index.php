<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PHP PDO CRUD</title>
</head>
<body>
    <h1>CRUD PHP WITH PDO</h1>
    <ul>
        <li><a href="adduser.php">Add user</a></li>
        <li><a href="listuser.php">List users</a></li>
    </ul>
</body>
</html>