<?php
namespace class_pdo;

require_once 'Conexion.php';

class User{
    private $id = NULL;
    private $name;
    private $phone;
    private $pdo;
    
    public function __construct(){
        $this->pdo = new Conexion();
    }
     public function addUser($name, $phone){
        $this->name = $name;
        $this->phone = $phone;
        
        return $this->saveUser();
    }
    
    private function saveUser(){
        $pdo = $this->pdo;
        $sql = "INSERT INTO user VALUES (:id, :name, :phone)";
        $query = $pdo->prepare($sql);
        $result = $query->execute([
            'id'=>$this->id,
            'name'=>$this->name,
            'phone'=>$this->phone
            ]);
        return $result;
    }
    
    public function getUsers(){
  $pdo = $this->pdo;
        $sql = "SELECT * FROM user";
        $query = $pdo->query($sql);
        $result = $query->fetchAll(\PDO::FETCH_ASSOC);
        return $result;

    }
    
    public function deleteUser($id){
        $pdo = $this->pdo;
        $sql = "DELETE FROM user WHERE id = :id";
        $query = $pdo->prepare($sql);
        $result = $query->execute([
            'id' =>$id
            ]);
            
    }public function updateUser($id, $name, $phone){
        $pdo = $this->pdo;
        $sql = "UPDATE users SET name = :name, phone = :phone WHERE id = :id";
        $query = $pdo->prepare($sql);
        $result = $query->execute([
            'id'=> $id,
            'name'=>$name,
            'phone'=>$phone
            ]);
        return $result;
    }
}
